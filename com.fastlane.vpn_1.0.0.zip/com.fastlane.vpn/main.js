function luna(cmd, callback) {
    var req = webOS.service.request(
        "luna://org.webosbrew.hbchannel",
        {
            method: "runCommand",
            parameters: { command: cmd },
            onSuccess: callback,
            onFailure: callback
        }
    );
}

function loadServers() {
    luna("cat /media/developer/xray/servers.json", function (res) {
        let data = JSON.parse(res.stdout || "[]");
        renderServers(data);
    });

    luna("cat /media/developer/xray/state.json", function (res) {
        try {
            let st = JSON.parse(res.stdout);
            document.getElementById("current").innerText =
                "Текущий сервер: " + st.current;
        } catch (e) {}
    });

    luna("pgrep xray", function (res) {
        document.getElementById("status").innerText =
            res.stdout ? "Статус: Xray работает" : "Статус: Xray остановлен";
    });
}

function renderServers(list) {
    let box = document.getElementById("servers");
    box.innerHTML = "";

    list.forEach(s => {
        let div = document.createElement("div");
        div.className = "card";

        let flag = s.name.match(/^./) || "🌐";

        div.innerHTML = `
            <div class="flag">${flag}</div>
            <h3>${s.name}</h3>
            <p>Тип: ${s.type}</p>
            <p>Сервер: ${s.server}</p>
            <p>Порт: ${s.port}</p>
            <button onclick="selectServer(${s.id})">Выбрать</button>
        `;

        box.appendChild(div);
    });
}

function selectServer(id) {
    luna(`/media/developer/xray/generate_config.sh ${id}`, function () {
        luna(`/media/developer/xray/restart_xray.sh`, function () {
            alert("Сервер выбран: " + id);
            loadServers();
        });
    });
}

document.getElementById("refreshBtn").onclick = function () {
    luna("/media/developer/xray/update_sub.sh", function () {
        luna("/media/developer/xray/parse_subscription.sh", function () {
            loadServers();
        });
    });
};

loadServers();
